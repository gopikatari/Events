const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const usersRouter = require("./routers/usersRouter");
const eventsRouter = require("./routers/eventsRouter");

const app = express();
//dot env
require("dotenv/config");

app.use(cors());
//
//express to accept data
app.use(express.json());
//middlewares -start

//middlewares end

//Routers -start
app.use("/api/users", usersRouter);
app.use("/api/events", eventsRouter);
//Routers end

app.use("/", (request, response) => {
  response.send(`<h2>EVENTS API RUNNING......... </h2>`);
});

//mongodbconnection

mongoose
  .connect(process.env.MONGODB_LOCAL_URL, {
    useCreateIndex: true,
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
  })
  .then(() => {
    console.log("connection to mongodb succesfull");
  })
  .catch((error) => {
    console.log(error);
    process.exit(1);
  });

//app.listen
app.listen(process.env.PORT, process.env.HOSTNAME, () => {
  console.log("API Running successfully");
});
