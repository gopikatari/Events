const express = require("express");
const router = express.Router();
const { body, validationResult } = require("express-validator");
const User = require("../models/user");
const gravatar = require("gravatar");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const authenticate = require("../middlewares/authenticate");

//Register an user

router.post(
  "/register",
  [
    body("name").notEmpty().withMessage("username is required"),
    body("email").notEmpty().withMessage("email is required"),
    body("password").notEmpty().withMessage("password is required"),
  ],
  async (request, response) => {
    let errors = validationResult(request);

    if (!errors.isEmpty()) {
      return response.status(500).json({ errors: errors.array() });
    }

    try {
      //check the emailid is alreayd exists or not
      let email = request.body.email;
      let name = request.body.name;
      let user = await User.findOne({ email: email });

      if (user)
        return response
          .status(401)
          .json({ errors: [{ msg: "User already exists" }] });

      //make isAdmin false by default
      let isAdmin = false;
      //get the gravator
      let avatar = gravatar.url(email, {
        s: "200",
        d: "mm",
        r: "pg",
      });

      //gen salt and encrypt the password

      let password = request.body.password;
      let salt = await bcrypt.genSalt(10);

      password = await bcrypt.hash(password, salt);

      let NewUser = { name, email, password, isAdmin, avatar };

      //save
      user = new User(NewUser);
      user = await user.save();
      if (user) {
        return response
          .status(200)
          .json({ msg: "Registration is successfull" });
      }
    } catch (error) {
      return response.status(500).json({ errors: [{ msg: error }] });
    }
  }
);

//Login an user

router.post(
  "/login",
  [
    body("email").notEmpty().withMessage("Email is required"),
    body("password").notEmpty().withMessage("Password is required"),
  ],
  async (request, response) => {
    const errors = validationResult(request);
    if (!errors.isEmpty())
      return response.status(500).json({ errors: errors.array() });
    try {
      //check user exists or not
      let email = request.body.email;
      let user = await User.findOne({ email: email });
      if (!user) {
        return response
          .status(500)
          .json({ errors: [{ msg: "Invalid Credentials" }] });
      }
      //check the password
      let password = request.body.password;
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return response
          .status(500)
          .json({ errors: [{ msg: "Invalid Credentials" }] });
      }
      //generate token with payload
      let payload = {
        user: {
          id: user.id,
          name: user.name,
        },
      };
      jwt.sign(
        payload,
        process.env.SECRET_KEY,
        { expiresIn: "5h" },
        (error, token) => {
          if (error) throw error;
          return response.status(201).json({
            msg: "login successfull",
            token: token,
            user: user,
          });
        }
      );
    } catch (error) {
      return response.status(500).json({ errors: [{ msg: error.message }] });
    }
  }
);

//get userdetails

router.get("/details", authenticate, async (request, response) => {
  try {
    let user = await User.findOne({ _id: request.user.id });
    return response.status(201).json({
      user: user,
    });
  } catch (error) {
    return response.status(500).json({ errors: [{ msg: error.message }] });
  }
});
module.exports = router;
