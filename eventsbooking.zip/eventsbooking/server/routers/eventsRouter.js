const express = require("express");
const router = express.Router();
const Event = require("../models/event");
const authenticate = require("../middlewares/authenticate");
const { body, validationResult } = require("express-validator");

router.get("/free", async (request, response) => {
  try {
    let freeEvents = await Event.find({ type: "FREE" });

    return response.status(200).json({ events: freeEvents });
  } catch (error) {
    return response.status(401).json({ errors: [{ msg: error }] });
  }
});

//pro

router.get("/pro", authenticate, async (request, response) => {
  try {
    let proEvents = await Event.find({ type: "PRO" });

    return response.status(200).json({ events: proEvents });
  } catch (error) {
    return response.status(401).json({ errors: [{ msg: error }] });
  }
});

//upload
router.post(
  "/upload",
  authenticate,
  [
    body("name").notEmpty().withMessage("name is required"),
    body("image").notEmpty().withMessage("image is required"),
    body("date").notEmpty().withMessage("date is required"),
    body("type").notEmpty().withMessage("type is required"),
    body("price").notEmpty().withMessage("price is required"),
    body("info").notEmpty().withMessage("info is required"),
  ],
  async (request, response) => {
    let errors = validationResult(request);
    if (!errors.isEmpty())
      return response.status(401).json({ errors: errors.array() });

    try {
      let { name, date, image, type, price, info } = request.body;
      let user = request.user.id;

      let event = new Event({ user, name, image, date, type, price, info });
      event = await event.save();
      if (event)
        return response
          .status(200)
          .json({ msg: "event uploaded successfully", event: event });
    } catch (error) {
      return response.status(401).json({ errors: [{ error: error }] });
    }
  }
);
module.exports = router;
