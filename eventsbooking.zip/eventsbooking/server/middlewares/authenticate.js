const jwt = require("jsonwebtoken");

let authenticate = (request, response, next) => {
  try {
    if (request.headers?.authorization === (null || undefined)) {
      return response
        .status(401)
        .json({ errors: [{ msg: "Invalid Token: Authorization denied " }] });
    }
    // let token = request.header("x-auth-token");
    let token = request.headers.authorization.split(" ")[1];

    //console.log(request.headers.authorization);
    if (!token) {
      return response
        .status(401)
        .json({ errors: [{ msg: "Invalid Token: Authorization denied " }] });
    }
    //verify the token
    let decoded = jwt.verify(token, process.env.SECRET_KEY);
    request.user = decoded.user;
    next();
  } catch (error) {
    console.log("Token==>" + error);
    return response.status(401).json({ errors: [{ msg: "Invalid token" }] });
  }
};

module.exports = authenticate;
