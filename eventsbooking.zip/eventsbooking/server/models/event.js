const mongoose = require("mongoose");

let eventSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  name: { type: String, required: true },
  type: { type: String, require: true },
  date: { type: String, require: true },
  price: { type: Number, require: true },
  image: { type: String, require: true },
  info: { type: String, require: true },
  dateCreated: { type: Date, default: Date.now() },
});

let Event = mongoose.model("Event", eventSchema);

module.exports = Event;
