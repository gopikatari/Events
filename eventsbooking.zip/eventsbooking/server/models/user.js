const mongoose = require("mongoose");

let userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, require: true },
  password: { type: String, require: true },
  isAdmin: { type: Boolean, require: true },
  avatar: { type: String, require: true },
  dateCreated: { type: Date, default: Date.now() },
});

let User = mongoose.model("User", userSchema);

module.exports = User;
