import React from "react";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { Link, useHistory } from "react-router-dom";
import logo from "../assets/images/logo.png";
import * as alertActions from "../redux/alert/alert.actionTypes";
import * as userActions from "../redux/user/user.actions";

const Register = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const [user, setUser] = useState({
    name: "",
    email: "",
    password: "",
  });

  const [userError, setUserError] = useState({
    nameError: "",
    emailError: "",
    passwordError: "",
  });

  const validateUsername = (event) => {
    setUser({
      ...user,
      [event.target.name]: event.target.value,
    });

    const usernameRegex = /^[A-Za-z0-9 ]{3,20}$/;
    if (!usernameRegex.test(event.target.value)) {
      setUserError({
        ...userError,
        nameError: "username is not valid",
      });
    } else {
      setUserError({
        ...userError,
        nameError: "",
      });
    }
  };
  const validateEmail = (event) => {
    setUser({
      ...user,
      [event.target.name]: event.target.value,
    });

    const ck_email =
      /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    if (!ck_email.test(event.target.value)) {
      setUserError({
        ...userError,
        emailError: "email is not valid",
      });
    } else {
      setUserError({
        ...userError,
        emailError: "",
      });
    }
  };

  const validatePassword = (event) => {
    setUser({
      ...user,
      [event.target.name]: event.target.value,
    });

    const ck_Password = /^[A-Za-z]\w{7,14}$/;
    if (!ck_Password.test(event.target.value)) {
      setUserError({
        ...userError,
        passwordError: "password is not valid",
      });
    } else {
      setUserError({
        ...userError,
        passwordError: "",
      });
    }
  };

  const handleRegisterClick = (event) => {
    event.preventDefault();
    if (
      user.name !== "" &&
      user.email !== "" &&
      user.password !== "" &&
      userError.nameError.length === 0 &&
      userError.emailError.length === 0 &&
      userError.passwordError.length === 0
    ) {
      dispatch(userActions.registerUser(user, history));
    } else {
      console.log("inError");
      dispatch(
        alertActions.setAlert("Please enter the valid information", "danger")
      );
    }
  };

  return (
    <React.Fragment>
      <div className="container">
        <div className="row mt-5">
          <div className="col-md-4 m-auto animated zoomIn">
            <div className="card">
              <div className="card-header bg-teal">
                <p className="h4 text-center text-white">Register here</p>
              </div>
              <div className="card-body bg-light">
                <form onSubmit={handleRegisterClick}>
                  <div className="form-group">
                    <input
                      type="name"
                      name="name"
                      placeholder="user name"
                      className={`form-control ${
                        userError.nameError.length > 0 ? "is-invalid" : ""
                      }`}
                      onChange={validateUsername}
                    />
                  </div>
                  <div className="form-group">
                    <input
                      type="text"
                      name="email"
                      placeholder="email"
                      className={`form-control ${
                        userError.emailError.length > 0 ? "is-invalid" : ""
                      }`}
                      onChange={validateEmail}
                    />
                  </div>

                  <div className="form-group">
                    <input
                      type="password"
                      name="password"
                      placeholder="password"
                      className={`form-control ${
                        userError.passwordError.length > 0 ? "is-invalid" : ""
                      }`}
                      onChange={validatePassword}
                    />
                  </div>
                  <div className="p-2">
                    <small>
                      Already have an account ?
                      <Link to="/users/login">Login</Link>
                    </small>
                  </div>
                  <input
                    type="submit"
                    value="Register"
                    className="btn btn-block bg-teal text-white "
                  />
                </form>
              </div>
              <div className="footer p-1 bg-light text-center">
                <img src={logo} alt="" className="" width="120" height="40" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default Register;
