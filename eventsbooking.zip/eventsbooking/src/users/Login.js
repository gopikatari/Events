import React from "react";
import logo from "../assets/images/logo.png";
import { Link, Redirect, useHistory } from "react-router-dom";
import { useState } from "react";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import * as userActions from "../redux/user/user.actions";
import { getToken } from "../rootUtils/userUtils";

const Login = (props) => {
  const history = useHistory();
  // redux
  const dispatch = useDispatch();
  //redux end

  const [dirty, setDirty] = useState({
    email: false,
    password: false,
  });

  const [errors, setErrors] = useState({
    email: [],
    password: [],
  });

  const [user, setUser] = useState({
    email: "",
    password: "",
  });

  let validate = () => {
    let errorData = {};

    //validate email
    errorData.email = [];
    if (!user.email) {
      errorData.email.push("Email should not be empty");
    }

    //validate password
    errorData.password = [];
    if (!user.password) {
      errorData.password.push("Password should not be empty");
    }
    setErrors(errorData);
  };

  useEffect(validate, [user]);

  let handleSubmit = (event) => {
    event.preventDefault();
    //make all fileds dirty
    let dirtyData = dirty;
    Object.keys(dirty).forEach((control) => {
      dirtyData[control] = true;
    });
    setDirty(dirtyData);

    //validate
    validate();

    //check is-form-valid
    if (valid()) {
      dispatch(userActions.loginUser(user, history));
      const { state } = props.location;
      //window.location = state ? state.from.pathname : "/";
      // alertify.error("Ok",);
    }
  };

  let valid = () => {
    let isvalid = true;
    Object.keys(errors).forEach((control) => {
      if (errors[control].length > 0) {
        isvalid = false;
      }
    });
    return isvalid;
  };

  if (getToken()) {
    return <Redirect to="/"></Redirect>;
  }

  return (
    <React.Fragment>
      {/* <span>{JSON.stringify(user)}</span>
      <span>{JSON.stringify(errors)}</span>
      <span>{JSON.stringify(dirty)}</span> */}

      <div className="container">
        <div className="row mt-5">
          <div className="col-md-4 m-auto animated zoomIn">
            <div className="card">
              <div className="card-header bg-teal">
                <p className="h4 text-center text-white">Login here</p>
              </div>
              <div className="card-body bg-light">
                <form onSubmit={handleSubmit}>
                  <div className="form-group">
                    <input
                      type="text"
                      name="email"
                      placeholder="email"
                      className="form-control"
                      value={user.email}
                      onChange={(event) =>
                        setUser({ ...user, email: event.target.value })
                      }
                      onBlur={() => {
                        setDirty({ ...dirty, email: true });
                        validate();
                      }}
                    />
                    <div className="text-danger">
                      <p className="font-small">
                        {dirty["email"] && errors["email"][0]
                          ? errors["email"]
                          : ""}
                      </p>
                    </div>
                  </div>

                  <div className="form-group">
                    <input
                      type="password"
                      name="password"
                      placeholder="passord"
                      className="form-control"
                      value={user.password}
                      onChange={(event) =>
                        setUser({ ...user, password: event.target.value })
                      }
                      onBlur={() => {
                        setDirty({ ...dirty, password: true });
                        validate();
                      }}
                    />
                    <div className="text-danger">
                      <p className="font-small">
                        {dirty["password"] && errors["password"][0]
                          ? errors["password"]
                          : ""}
                      </p>
                    </div>
                  </div>
                  <div className="p-2">
                    <small>
                      Dont have an account ?
                      <Link to="/users/register">Register</Link>
                    </small>
                  </div>
                  <input
                    type="submit"
                    value="Login"
                    className="bg-teal btn btn-teal btn-sm btn-block my-2 text-white"
                  />
                </form>
              </div>
              <div className="footer p-1 bg-light text-center">
                <img src={logo} alt="" className="" width="120" height="40" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default Login;
