import React from "react";
import { useSelector } from "react-redux";
import * as alertReducer from "../../redux/alert/alert.reducer";

const Alert = () => {
  const alertlist = useSelector((store) => {
    return store[alertReducer.alertFeatureKey];
  });

  //console.log(info);
  //const [alertlist, setAlertlist] = useState([]);

  const close = () => {};
  return (
    <React.Fragment>
      {alertlist.length > 0 ? (
        <React.Fragment>
          <div
            className={`alert alert-${alertlist[0].color} alert-dismissible m-2 fixed-top animated zoomIn`}
          >
            {alertlist.map((alert) => (
              <span key={alert.id}>{alert.message}</span>
            ))}
            <button
              type="button"
              className="close"
              data-dismiss="alert"
              aria-label="Close"
            >
              <span onClick={close} aria-hidden="true">
                &times;
              </span>
            </button>
          </div>
        </React.Fragment>
      ) : (
        ""
      )}
    </React.Fragment>
  );
};

export default Alert;
