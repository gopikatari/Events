import React from "react";
import spinner from "../../assets/images/spinner.gif";
const Spinner = () => {
  return (
    <React.Fragment>
      <img src={spinner} alt="" className="d-block m-auto" />
    </React.Fragment>
  );
};

export default Spinner;
