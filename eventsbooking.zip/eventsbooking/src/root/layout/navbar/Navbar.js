import React from "react";
import { useDispatch } from "react-redux";
import { Link, NavLink, useHistory } from "react-router-dom";
import Logo from "../../../assets/images/logo.png";
import * as userUtils from "../../../rootUtils/userUtils";
import * as userActions from "../../../redux/user/user.actions";
import * as userReducer from "../../../redux/user/user.reducer";
import { useSelector } from "react-redux";

const Navbar = () => {
  const dispatch = useDispatch();

  const userInfo = useSelector((state) => {
    return state[userReducer.userFeaturekey];
  });
  const { user } = userInfo;
  const history = useHistory();
  let logoutClick = () => {
    dispatch(userActions.logoutUser(history));
  };
  const beforeLinks = (
    <React.Fragment>
      <li className="nav-item">
        <NavLink
          to="/users/login"
          className="nav-link"
          activeClassName="active"
        >
          <i className="fa fa-user-cog"></i> Login
        </NavLink>
      </li>
      <li className="nav-item">
        <NavLink
          to="/users/register"
          className="nav-link"
          activeClassName="active"
        >
          <i className="fa fa-sign-in-alt"></i> Register
        </NavLink>
      </li>
    </React.Fragment>
  );

  const AfterLinks = (
    <React.Fragment>
      <li className="nav-item ">
        <Link to="/profile" className="nav-link ">
          <img
            alt=""
            src={user?.avatar}
            width="25"
            height="25"
            className="rounded-circle"
          />
          <span className="px-2">{user?.name}</span>
        </Link>
      </li>
      <li className="nav-item">
        <Link to="/users/login" className="nav-link" onClick={logoutClick}>
          <i className="fa fa-user-lock"></i> Logout
        </Link>
      </li>
    </React.Fragment>
  );

  return (
    <React.Fragment>
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
        <div className="container">
          <Link to="/">
            <img src={Logo} alt="" className="navbar-brand" />
          </Link>
          <div className="navbar-collapse collapse">
            <ul className="navbar-nav  mx-2">
              <li className="nav-item">
                <NavLink
                  to="/events/free"
                  className="nav-link"
                  activeClassName="active"
                >
                  Free Events
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  to="/events/pro"
                  className="nav-link"
                  activeClassName="active"
                >
                  Pro Events
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  to="/events/upload"
                  className="nav-link"
                  activeClassName="active"
                >
                  Upload
                </NavLink>
              </li>
            </ul>

            <ul className="navbar-nav ml-auto">
              {userUtils.isLoggedIn() ? AfterLinks : beforeLinks}
            </ul>
          </div>
        </div>
      </nav>
    </React.Fragment>
  );
};

export default Navbar;
