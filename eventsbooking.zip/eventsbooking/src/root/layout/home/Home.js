import React from "react";
const Home = () => {
  return (
    <React.Fragment>
      <section className="p3">
        <div className="landing-page">
          <div className="wrapper">
            <div className="d-flex flex-column justify-content-center text-center align-items-center h-100">
              <h2 className="display-4">Events Booking</h2>
              <p className="mx-2">
                Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                Maiores incidunt perspiciatis, nesciunt doloribus eligendi
                possimus, perferendis, ratione aut ducimus minus fugit? Rerum
                sed, quidem impedit est adipisci optio necessitatibus.
                Perspiciatis.
              </p>
            </div>
          </div>
        </div>
      </section>
    </React.Fragment>
  );
};

export default Home;
