import axios from "axios";
import * as userUtils from "./userUtils";
export const setToken = (token) => {
  if (token) {
    axios.defaults.headers.common[
      "Authorization"
    ] = `Bearer ${userUtils.getToken()}`;
  } else {
    delete axios.defaults.headers.common["Authorization"];
  }
};

export const removeToken = () => {
  if (!userUtils.getToken()) {
    axios.defaults.headers.common["Authorization"] = "";
    delete axios.defaults.headers.common["Authorization"];
  }
};
