import React, { useEffect } from "react";
import "./App.css";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  useHistory,
} from "react-router-dom";
import Navbar from "./root/layout/navbar/Navbar";
import Home from "./root/layout/home/Home";
import FreeEvent from "./events/free-event";
import ProEvent from "./events/pro-event";
import UploadEvent from "./events/upload-event";
import Login from "./users/Login";
import Register from "./users/Register";
import Alert from "./root/utils/Alert";

import { useDispatch } from "react-redux";

import * as userActions from "./redux/user/user.actions";
import * as userUtils from "./rootUtils/userUtils";
import PrivateRoute from "./rootUtils/privateRoute";

const App = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  useEffect(() => {
    if (userUtils.getToken()) {
      dispatch(userActions.getUserInfo(history));
    }
  });

  return (
    <React.Fragment>
      <Router>
        <Navbar />
        <Alert />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/events/free" component={FreeEvent} />
          <PrivateRoute exact path="/events/pro" component={ProEvent} />
          <PrivateRoute exact path="/events/upload" component={UploadEvent} />

          <Route exact path="/users/login" component={Login} />
          <Route exact path="/users/Register" component={Register} />
        </Switch>
      </Router>
    </React.Fragment>
  );
};

export default App;
