import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Spinner from "../root/utils/Spinner";
import * as eventReducer from "../redux/event/event.reducer";
import * as eventActions from "../redux/event/event.actions";

import EventCard from "../common/EventCard";
const ProEvent = () => {
  const dispatch = useDispatch();
  const eventsInfo = useSelector((state) => {
    return state[eventReducer.EventsFeatureKey];
  });

  useEffect(() => {
    dispatch(eventActions.getProEvents());
  }, [dispatch]);

  const { loading, events } = eventsInfo;

  return (
    <React.Fragment>
      {loading ? (
        <Spinner />
      ) : (
        <React.Fragment>
          <section className="pt-3">
            <div className="container">
              <div className="row">
                <div className="col">
                  <p className="h3 font-weight-bold text-success">PRO Events</p>
                  <p className="lead">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Et, facilis quidem. Adipisci minima consequuntur, ullam
                    soluta quaerat illum beatae, autem laborum eligendi, quae
                    voluptate dolorum culpa voluptatem rerum facere aspernatur
                    corrupti aliquid? Neque delectus recusandae perspiciatis
                    sunt ipsum libero fuga quos omnis dignissimos quas. Cumque..
                  </p>
                  <p className="lead text-primary">
                    Available Events : {events.length}
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section>
            {events.length > 0 ? (
              <React.Fragment>
                {events.map((event) => (
                  <EventCard
                    key={event._id}
                    event={event}
                    className="pb-2 mb-2"
                  />
                ))}
              </React.Fragment>
            ) : null}
          </section>
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default ProEvent;
