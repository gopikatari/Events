import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import * as eventReducer from "../redux/event/event.reducer";
import * as eventActions from "../redux/event/event.actions";
import Spinner from "../root/utils/Spinner";
import EventCard from "../common/EventCard";

const FreeEvent = () => {
  const dispatch = useDispatch();
  const eventsInfo = useSelector((state) => {
    return state[eventReducer.EventsFeatureKey];
  });

  useEffect(() => {
    dispatch(eventActions.getFreeEvents());
    return () => {};
  }, [dispatch]);

  const { events, loading } = eventsInfo;
  console.log(events);
  return (
    <React.Fragment>
      {loading ? (
        <Spinner />
      ) : (
        <React.Fragment>
          <section className="pt-3">
            <div className="container">
              <div className="row">
                <div className="col">
                  <p className="h3 font-weight-bold text-teal">Free Events</p>
                  <p className="lead">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Et, facilis quidem. Adipisci minima consequuntur, ullam
                    soluta quaerat illum beatae, autem laborum eligendi, quae
                    voluptate dolorum culpa voluptatem rerum facere aspernatur
                    corrupti aliquid? Neque delectus recusandae perspiciatis
                    sunt ipsum libero fuga quos omnis dignissimos quas. Cumque..
                  </p>
                  <p className="lead text-primary">
                    Available Events : {events.length}
                  </p>
                </div>
              </div>
            </div>
          </section>
          {events.length > 0 ? (
            <React.Fragment>
              {events.map((event) => (
                <EventCard event={event} className="pb-2 mb-2" />
              ))}
            </React.Fragment>
          ) : null}
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default FreeEvent;
