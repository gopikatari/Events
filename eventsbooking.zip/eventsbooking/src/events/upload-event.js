import React from "react";
import { useState } from "react";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router";
import * as eventActions from "../redux/event/event.actions";
import * as userReducer from "../redux/user/user.reducer";
const UploadEvent = () => {
  const userInfo = useSelector((state) => {
    return state[userReducer.userFeaturekey];
  });
  const { user } = userInfo;

  const dispatch = useDispatch();
  const history = useHistory();
  const [event, setEvent] = useState({
    name: "",
    type: "",
    image: "",
    price: 0,
    date: "",
    info: "",
  });

  let handleInputChange = (e) => {
    setEvent({
      ...event,
      [e.target.name]: e.target.value,
    });
  };
  let handleSubmit = (e) => {
    e.preventDefault();
    dispatch(eventActions.uploadEvent(event, history));
  };
  return (
    <React.Fragment>
      <section className="p-2 m-3">
        <div className="container">
          <pre>{JSON.stringify(event)}</pre>
          <div className="row">
            <div className="col">
              <p className="h4 text-primary ">
                <i className="fa fa-file-upload pr-3"></i>
                Upload an Event
              </p>
              <p className="">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla
                soluta, nostrum ea labore voluptatum neque voluptate rem tempore
                praesentium tenetur, veniam aliquam ipsa ullam natus ducimus.
                Magnam a iste iure.
              </p>
            </div>
          </div>
        </div>
      </section>

      {user?.isAdmin ? (
        <React.Fragment>
          <section>
            <div className="container">
              <div className="row">
                <div className="col-md-8 bg-light p-3">
                  <form action="" onSubmit={handleSubmit}>
                    <div className="form-group">
                      <input
                        type="text"
                        name="name"
                        placeholder="event name"
                        value={event.name}
                        onChange={handleInputChange}
                        className="form-control"
                      />
                    </div>
                    <div className="form-group">
                      <select
                        name="type"
                        className="form-control"
                        value={event.type}
                        onChange={handleInputChange}
                      >
                        <option value="">select event type</option>
                        <option value="PRO">PRO EVENT</option>
                        <option value="FREE">FREE EVENT</option>
                      </select>
                    </div>
                    <div className="form-group">
                      <input
                        type="date"
                        name="date"
                        value={event.date}
                        onChange={handleInputChange}
                        className="form-control"
                      />
                    </div>
                    <div className="form-group">
                      <input
                        type="text"
                        name="image"
                        placeholder="image of the event"
                        className="form-control"
                        value={event.image}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="form-group">
                      <input
                        type="Number"
                        name="price"
                        placeholder="price of an event"
                        className="form-control"
                        value={event.price}
                        onChange={handleInputChange}
                      />
                    </div>

                    <div className="form-group">
                      <textarea
                        name="info"
                        cols="4"
                        rows="4"
                        className="form-control"
                        placeholder="Event information"
                        value={event.info}
                        onChange={handleInputChange}
                      ></textarea>
                    </div>
                    <div className="form-group">
                      <input
                        type="submit"
                        className="btn btn-cyan"
                        value="upload"
                      />
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </section>
        </React.Fragment>
      ) : (
        <React.Fragment>
          <div className="container">
            <div className="row">
              <div className="col text-center text-danger">
                <p className="h3">
                  ------------- You are not authorized to view this
                  page!----------------
                </p>
              </div>
            </div>
          </div>
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default UploadEvent;
