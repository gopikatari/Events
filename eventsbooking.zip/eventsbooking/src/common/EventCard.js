import React from "react";
const EventCard = (props) => {
  const { event } = props;
  return (
    <section className="p-2">
      <div className="container">
        <div className="card">
          <img src={event?.image} alt="" width="100%" height="100%" />
          <div className="card-header bg-info p-2">
            <p className="h4 m-2 text-white">{event?.name}</p>
          </div>
          <div className="card-footer mt-0 bg-light">
            <div className="row mb-0">
              <div className="col">
                <p className="h4">DATE : {event?.date}</p>
                <p className="h6">PRICE : {event?.type}</p>
              </div>
              <div className="col">
                <button className="btn btn-teal btn-sm">Book Event.</button>
              </div>
            </div>
            <div className="row">
              <div className="col">
                <p className="">{event?.info}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EventCard;
