import axios from "axios";
import * as alertActions from "../alert/alert.actionTypes";
import * as userUtils from "../../rootUtils/userUtils";
import * as tokenUtils from "../../rootUtils/tokenUtils";

export const LOGIN_USER_REQUEST = "LOGIN_USER_REQUEST";
export const LOGIN_USER_SUCCESS = "LOGIN_USER_SUCCESS";
export const LOGIN_USER_FAILURE = "LOGIN_USER_FAILURE";

export const REGISTER_USER_REQUEST = "REGISTER_USER_REQUEST";
export const REGISTER_USER_SUCCESS = "REGISTER_USER_SUCCESS";
export const REGISTER_USER_FAILURE = "REGISTER_USER_FAILURE";

export const GET_USERINFO_REQUEST = "GET_USERINFO_REQUEST";
export const GET_USERINFO_SUCCESS = "GET_USERINFO_SUCCESS";
export const GET_USERINFO_FAILURE = "GET_USERINFO_FAILURE";

export const LOGOUT_USER = "LOGOUT_USER";

export const registerUser = (user, history) => {
  return async (dispatch) => {
    let response;
    try {
      let dataURL = `http://127.0.0.1:5000/api/users/register`;
      dispatch({ type: REGISTER_USER_REQUEST });
      response = await axios.post(dataURL, user);
      dispatch({ type: REGISTER_USER_SUCCESS, payload: response.data });
      dispatch(alertActions.setAlert(response.data.msg, "success"));
      // dispatch({ type: REGISTER_USER_FAILURE, payload: response });
      //dispatch(alertActions.setAlert(error.message, "danger"));
      history.push("/");
    } catch (error) {
      console.log(error.response.data);
      dispatch({
        type: REGISTER_USER_FAILURE,
        payload: error.response.data,
      });
      let errorsData = error.response.data.errors;
      for (let err of errorsData) {
        dispatch(alertActions.setAlert(err.msg, "danger"));
      }
      //
    }
  };
};

//Login
export const loginUser = (user, history) => {
  return async (dispatch) => {
    try {
      let dataURL = `http://127.0.0.1:5000/api/users/login`;
      dispatch({ type: LOGIN_USER_REQUEST });
      let response = await axios.post(dataURL, user);
      dispatch({ type: LOGIN_USER_SUCCESS, payload: response.data });

      history.push("/");
      // dispatch(alertActions.setAlert(response.data.msg, "success"));
    } catch (error) {
      dispatch({ type: LOGIN_USER_FAILURE, payload: error.response.data });
      for (let err of error.response.data.errors) {
        dispatch(alertActions.setAlert(err.msg, "danger"));
      }
    }
  };
};

export const logoutUser = (history) => {
  return async (dispatch) => {
    dispatch({ type: LOGOUT_USER });
    history.push("/users/login");
  };
};

export const getUserInfo = (history) => {
  return async (dispatch) => {
    try {
      if (userUtils.getToken()) {
        tokenUtils.setToken(userUtils.getToken());
      } else {
        dispatch({
          type: GET_USERINFO_FAILURE,
          payload: "Authorzation denied",
        });
        dispatch(alertActions.setAlert("Authorizaion Denied", "danger"));
      }
      let dataURL = `http://localhost:5000/api/users/details`;
      dispatch({ type: GET_USERINFO_REQUEST });
      let response = await axios.get(dataURL);
      dispatch({ type: GET_USERINFO_SUCCESS, payload: response.data });
    } catch (error) {
      dispatch({ type: GET_USERINFO_FAILURE, payload: error.message });
      dispatch({ type: LOGOUT_USER });
      dispatch(alertActions.setAlert("Authorizaion Denied", "danger"));
    }
  };
};
