import * as userActions from "./user.actions";

export const userFeaturekey = "UserInfo";

let initalState = {
  user: {},
  errorMessage: "",
  token: "",
  loading: false,
  isAuthenticated: false,
};

export const reducer = (state = initalState, action) => {
  let { type, payload } = action;
  switch (type) {
    case userActions.REGISTER_USER_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case userActions.REGISTER_USER_SUCCESS:
      return {
        ...state,
        loading: false,
      };
    case userActions.REGISTER_USER_FAILURE:
      return {
        ...state,
        loading: false,
        errorMessage: payload,
      };

    case userActions.LOGIN_USER_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case userActions.LOGIN_USER_SUCCESS:
      localStorage.setItem("events-token", payload.token);
      return {
        ...state,
        loading: false,
        user: payload.user,
        token: payload.token,
        isAuthenticated: true,
      };
    case userActions.LOGIN_USER_FAILURE:
      localStorage.removeItem("events-token");
      return {
        ...state,
        user: {},
        token: "",
        isAuthenticated: false,
        errorMessage: payload,
        loading: false,
      };

    case userActions.LOGOUT_USER:
      localStorage.removeItem("events-token");
      return {
        ...state,
        user: {},
        token: "",
        isAuthenticated: false,
      };

    case userActions.GET_USERINFO_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case userActions.GET_USERINFO_SUCCESS:
      return {
        ...state,
        loading: false,
        user: payload.user,
      };
    case userActions.GET_USERINFO_FAILURE:
      return {
        ...state,
        loading: false,
        errorMessage: payload,
        user: {},
      };
    default:
      return state;
  }
};
