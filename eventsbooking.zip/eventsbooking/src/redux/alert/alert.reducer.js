import * as alertActionTypes from "./alert.actionTypes";

export const alertFeatureKey = "Alert";

let initialState = [];
export const reducer = (state = initialState, action) => {
  let { type, payload } = action;
  switch (type) {
    case alertActionTypes.SET_ALERT:
      return [...state, payload];
    case alertActionTypes.REMOVE_ALERT:
      return state.filter((alert) => alert.id !== payload.id);
    default:
      return initialState;
  }
};
