import { combineReducers } from "redux";
import * as alertReducer from "../redux/alert/alert.reducer";
import * as userReducer from "../redux/user/user.reducer";
import * as eventReducer from "../redux/event/event.reducer";

const rootReducer = combineReducers({
  [alertReducer.alertFeatureKey]: alertReducer.reducer,
  [userReducer.userFeaturekey]: userReducer.reducer,
  [eventReducer.EventsFeatureKey]: eventReducer.reducer,
});

export default rootReducer;
