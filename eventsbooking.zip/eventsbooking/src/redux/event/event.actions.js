import axios from "axios";
import * as alertActions from "../alert/alert.actionTypes";
import * as userUtils from "../../rootUtils/userUtils";
import * as tokenUtils from "../../rootUtils/tokenUtils";
export const EVENT_UPLOAD_REQUEST = "EVENT_UPLOAD_REQUEST";
export const EVENT_UPLOAD_SUCCESS = "EVENT_UPLOAD_SUCCESS";
export const EVENT_UPLOAD_FAILURE = "EVENT_UPLOAD_FAILURE";

export const GET_FREEEVENT_REQUEST = "GET_FREEEVENT_REQUEST";
export const GET_FREEEVENT_SUCCESS = "GET_FREEEVENT_SUCCESS";
export const GET_FREEEVENT_FAILURE = "GET_FREEEVENT_FAILURE";

export const GET_PROEVENT_REQUEST = "GET_PROEVENT_REQUEST";
export const GET_PROEVENT_SUCCESS = "GET_PROEVENT_SUCCESS";
export const GET_PROEVENT_FAILURE = "GET_PROEVENT_FAILURE";

export const uploadEvent = (event, history) => {
  return async (dispatch) => {
    try {
      let dataURL = `http://localhost:5000/api/events/upload`;
      dispatch({ type: EVENT_UPLOAD_REQUEST });
      let response = await axios.post(dataURL, event);
      dispatch({ type: EVENT_UPLOAD_SUCCESS, payload: response.data });
      dispatch(alertActions.setAlert(response.data.msg, "success"));
      if (event.type === "FREE") history.push("/events/free");
      if (event.type === "PRO") history.push("/events/pro");
    } catch (error) {
      dispatch({ type: EVENT_UPLOAD_FAILURE, payload: error.message });
      dispatch(alertActions.setAlert(error.message, "danger"));
      history.push("/users/login");
    }
  };
};

export const getFreeEvents = () => {
  return async (dispatch) => {
    try {
      let dataURL = `http://localhost:5000/api/events/free`;
      dispatch({ type: GET_FREEEVENT_REQUEST });
      let response = await axios.get(dataURL);
      dispatch({ type: GET_FREEEVENT_SUCCESS, payload: response.data });
    } catch (error) {
      dispatch({ type: GET_FREEEVENT_FAILURE, payload: error.message });
      dispatch(alertActions.setAlert(error.message, "danger"));
    }
  };
};

export const getProEvents = () => {
  return async (dispatch) => {
    try {
      if (userUtils.getToken()) {
        tokenUtils.setToken(userUtils.getToken());
      } else {
        tokenUtils.removeToken();
        dispatch(alertActions.setAlert("Authorizaion Denied", "danger"));
      }

      let dataURL = `http://localhost:5000/api/events/pro`;
      dispatch({ type: GET_PROEVENT_REQUEST });
      let response = await axios.get(dataURL);
      dispatch({ type: GET_PROEVENT_SUCCESS, payload: response.data });
    } catch (error) {
      dispatch({ type: GET_PROEVENT_FAILURE, payload: error.message });
    }
  };
};
