import * as eventActions from "../event/event.actions";
const initalState = {
  events: [],
  loading: false,
  errorMessage: "",
};
export const EventsFeatureKey = "Events";
export const reducer = (state = initalState, action) => {
  const { type, payload } = action;
  switch (type) {
    case eventActions.EVENT_UPLOAD_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case eventActions.EVENT_UPLOAD_SUCCESS:
      return {
        ...state,
        loading: false,
      };
    case eventActions.EVENT_UPLOAD_FAILURE:
      return {
        ...state,
        loading: false,
        errorMessage: payload,
      };

    case eventActions.GET_FREEEVENT_REQUEST:
      return {
        ...state,
        loading: true,
      };

    case eventActions.GET_FREEEVENT_SUCCESS:
      return {
        ...state,
        loading: false,
        events: payload.events,
      };
    case eventActions.GET_FREEEVENT_FAILURE:
      return {
        ...state,
        loading: false,
        errorMessage: payload,
        events: [],
      };

    case eventActions.GET_PROEVENT_REQUEST:
      return {
        ...state,
        loading: true,
      };

    case eventActions.GET_PROEVENT_SUCCESS:
      return {
        ...state,
        loading: false,
        events: payload.events,
      };
    case eventActions.GET_PROEVENT_FAILURE:
      return {
        ...state,
        loading: false,
        errorMessage: payload,
        events: [],
      };
    default:
      return state;
  }
};
